from superwires import games
games.init(screen_width=640, screen_height=480, fps=50)
def main():
    #loud sfx
    shoot=games.load_sound("soundfx/Laser_Shoot7.wav")
    thrust=games.load_sound("envsounds/Move.wav")
    explosion=games.load_sound("soundfx/Energy explosion Sound Effect.ogg")
    levelup=games.load_sound("soundfx/Powerup.wav")

    #load themes
    games.music.load("theme/theme.ogg")

    #create menu
    choice=None
    while choice!="0":
        print(
            """Sounds and music
            0=Quit
            1=Play missile sound
            2=Loop Missile sound
            3=Stop Missile sound
            4=Play theme music
            5=Loop theme music
            6=Stop theme music
            7=Play Explosion
            8=Loop explosion
            9=stop explosion
            10=play thrust sound
            11=loop thrust sound
            12=stop thrust sound
            
            """
        )
        choice=input("Choice: ")
        print()
        #exit
        if choice=="0":
            print("Good_bye")
        #play missile sound
        elif choice=="1":
            shoot.play()
            print("Playing Missile sound")
        #loop missile sound
        elif choice=="2":
            loop=(int(input("Loop how many extra times? (-1 = forever)")))
            shoot.play(loop)
            print("Looping shoot")
        #stop sound
        elif choice=="3":
            shoot.stop()
            print("Stopping loop.")
        #theme song
        elif choice=="4":
            games.music.play()
            print("Playing music")
        #loop theme
        elif choice=="5":
            games.music.play(loop)
            print("Looping music")
        #stop theme
        elif choice=="6":
            games.music.stop()
            print("Stopping music")
        # play explosion sound
        elif choice == "7":
            explosion.play()
            print("Playing Missile sound")
        # loop explosion sound
        elif choice == "8":
            loop = (int(input("Loop how many extra times? (-1 = forever)")))
            explosion.play(loop)
            print("Looping shoot")
        # stop sound
        elif choice == "9":
            explosion.stop()
            print("Stopping loop.")
        # play missile sound
        elif choice == "10":
            thrust.play()
            print("Playing thrust sound")
        # loop missile sound
        elif choice == "11":
            loop = (int(input("Loop how many extra times? (-1 = forever)")))
            thrust.play(loop)
            print("Looping thrust")
        # stop sound
        elif choice == "12":
            thrust.stop()
            print("Stopping loop.")


    games.screen.mainloop()
main()