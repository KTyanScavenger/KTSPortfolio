#"Infinite" by Kyla Ryan
# 4/19

#Imports~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

from superwires import games, color
import random, sys



###############
#Screen creation~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


SH=600  #Height of screen for future use
SW=1920 #Width of screen for future use (I got these from the background image(s))
games.init(screen_width=SW, screen_height=SH, fps=60)

score=0

life=3

thanos_is_a_mean_boy=5
thanos_is_a_mean_boy2=6
thanos_is_the_ultimate_mean_boy=7
#thanos=""

speed_check=0



play=False
###############
#Classes~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class Stones(games.Sprite):

    global score
    #Load image
    space_image=games.load_image("images/stones/png/spacesto.png", transparent=True)
    power_image = games.load_image("images/stones/png/powersto.png", transparent=True)
    mind_image = games.load_image("images/stones/png/mindsto.png", transparent=True)
    soul_image = games.load_image("images/stones/png/soulsto.png", transparent=True)
    time_image = games.load_image("images/stones/png/timesto.png", transparent=True)
    reality_image = games.load_image("images/stones/png/realitysto.png", transparent=True)
    stonesls = [space_image, power_image, mind_image, soul_image, time_image, reality_image]
    image = random.choice(stonesls)

    speed=3
    def __init__(self,image, x, y=273):

        super(Stones, self).__init__(image=image, x=x, y=y, dy=Stones.speed)



    def update(self):
        if self.bottom>games.screen.height:
            self.destroy()

            self.lose_life()

    def handle_catch(self):
        self.destroy()
        global speed_check
        global score
        score+=10
        speed_check += 10


        

    def lose_life(self):
        global life
        life-=1



class Orb(games.Sprite):
    orb_img = games.load_image("images/orb.png", transparent=True)

    def __init__(self):
        super(Orb, self).__init__(image=Orb.orb_img, x=games.mouse.x, bottom=games.screen.height)

    def update(self):
        global life
        self.x=games.mouse.x
        if self.left<0:
            self.left=0
        if self.right>games.screen.width:
            self.right=games.screen.width
        if life<=0:
            self.endgame()

        self.check_catch()


    def check_catch(self):
        for stone in self.overlapping_sprites:

            stone.handle_catch()



    def endgame(self):
        global thanos
        Game.thanos.destroy()
        self.destroy()
        games.music.stop()
        games.music.load("8_bit_themes/Marvel.ogg")
        games.music.play()
        end_message=games.Message(value="You have failed",
                                  size=200,
                                  color=color.light_gray,
                                  x=games.screen.width/2,
                                  y=games.screen.height/2,
                                  lifetime=20*games.screen.fps,
                                  after_death=games.screen.quit
                                  )

        games.screen.add(end_message)
        highscore = HSVal()
        games.screen.add(highscore)







class Background(games.Sprite):

    bg_img1 = games.load_image("images/bkgrnd.jpg", transparent=False)
    bg_img2 = games.load_image("images/bkgrnd-1lf.jpg", transparent=False)
    bg_img3 = games.load_image("images/bkgrnd-2lf.jpg", transparent=False)
    bg_img4 = games.load_image("images/bkgrnd-3lf.jpg", transparent=False)


    #set images for animation in order of animation
    #bkgrnd-3lf.jpg
    bgend_1=games.load_image("images/bkgrndmovrg0.2.jpg", transparent=False)
    bgend_2=games.load_image("images/bkgrndmovrg0.4.jpg",transparent=False)
    bgend_3=games.load_image("images/bkgrndgmovr1.jpg",transparent=False)
    bgend_4=games.load_image("images/bkgrndmovrg0.6.jpg",transparent=False)
    bgend_5=games.load_image("images/bkgrndmovrg0.8.jpg",transparent=False)
    bgend_6=games.load_image("images/bkgrndgmovr2.jpg",transparent=False)
    bgend_7=games.load_image("images/bkgrndgmovr2.2.jpg",transparent=False)
    bgend_8=games.load_image("images/bkgrndgmovr2.4.jpg",transparent=False)
    bgend_9=games.load_image("images/bkgrndgmovr2.6.jpg",transparent=False)
    bgend_10=games.load_image("images/bkgrndgmovr2.8.jpg",transparent=False)
    bgend_11=games.load_image("images/bkgrndgmovr2.9.jpg",transparent=False)
    bgend_12=games.load_image("images/bkgrndgmovr3.jpg",transparent=False)

    backgrounds_list = [bg_img1, bg_img2, bg_img3, bg_img4]

    def __init__(self):
        super(Background, self).__init__(image=Background.bg_img1, y=games.screen.height/2, x=games.screen.width/2,
                                         is_collideable=False)




    def update(self):
        bg_num=self.ch_background()


        if bg_num==3:
            #set background animation to run
            self.animation()


        else:
            self.image = Background.backgrounds_list[bg_num]

            # if bg_num_go==0:
            #
            #     bg_num_go1=self.game_over_bg2()
            #     self.image=Background.game_over_list[bg_num_go1]
            #
            # if bg_num_go==1:
            #
            #         bg_num_go2=self.game_over_bg3()
            #         self.image=Background.game_over_list[bg_num_go2]


    def ch_background(self):
        global life
        if life>=3:
            return 0
        elif life==2:
            return 1
        elif life==1:
            return 2
        else:
            return 3

    def animation(self):


        background_animation=["images/bkgrndmovrg0.2.jpg",
                              "images/bkgrndmovrg0.4.jpg",
                              "images/bkgrndgmovr1.jpg",
                              "images/bkgrndmovrg0.6.jpg",
                              "images/bkgrndmovrg0.8.jpg",
                              "images/bkgrndgmovr2.jpg",
                              "images/bkgrndgmovr2.2.jpg",
                              "images/bkgrndgmovr2.4.jpg",
                              "images/bkgrndgmovr2.6.jpg",
                              "images/bkgrndgmovr2.8.jpg",
                              "images/bkgrndgmovr2.9.jpg",
                              "images/bkgrndgmovr3.jpg"
                              ]
        lose_life = games.Animation(images=background_animation,
                                    x=games.screen.width / 2,
                                    y=games.screen.height / 2,
                                    n_repeats=1,
                                    repeat_interval=25, is_collideable=False)

        games.screen.add(lose_life)

        end_image = self.bgend_12
        games.screen.background=end_image

        Orb.endgame(self)


class Thanos(games.Sprite):
    thanos_img=games.load_image("images/thanos.bmp", transparent=True)
    thanos_speed = 2

    def __init__(self, y=100, speed=2, odds_change=100):
        super(Thanos, self).__init__(image=Thanos.thanos_img, x=games.screen.width/2, y=y, dx=speed)
        self.odds_change=odds_change
        self.time_til_drop=0
        self.speed=speed
        self.thanos_score=0



    def update(self):
        global speed_check
        print(speed_check)
        if speed_check==100:
            print("updating")
            self.speed+=2
            speed_check=0
            self.dx=self.speed

        if self.left<0 or self.right > games.screen.width:
            self.dx=-self.dx
        elif random.randrange(self.odds_change)==0:
            self.dx=-self.dx
        self.check_drop()








    def check_drop(self):
        global play
        if self.time_til_drop>0:

            self.time_til_drop-=1
        elif self.time_til_drop<=0  and play==True:
            image = random.choice(Stones.stonesls)
            new_stone=Stones(image=image,x=self.x)
            games.screen.add(new_stone)
            self.time_til_drop=random.randrange(10,200)

class SCVal(games.Text):

    def __init__(self):
      super(SCVal, self).__init__(value="Score: ", size=40, color=color.light_gray, x=250, y=500, is_collideable=False)


    def update(self):

        self.value=score
        self.x=150



class HSVal(games.Text):
    def __init__(self):
        super(HSVal, self).__init__(value="Highscore: ", size=50, color=color.light_gray, x=150, y=450,
                                   is_collideable=False)
        # highscore = open("highscore.txt", "r+")
        # highscore.seek(0.0)
        # self.hs = highscore.readline()
        # highscore.close()

    def update(self):
        self.value="Highscore: "+self.save_hs()

    def save_hs(self):
        highscore = open("highscore.txt", "r+")
        highscore.seek(0.0)
        hs = highscore.readline()



        if int(hs) <= score:
            highscore=open("highscore.txt","w")

            highscore.seek(0.0)
            highscore.write(str(score))
        highscore.close()
        return hs









class SCLab(games.Text):
    def __init__(self):
        super(SCLab, self).__init__(value="Score: ", size=40, color=color.light_gray, x=80, y=500, is_collideable=False)



class Main_title(games.Text):
    def __init__(self):
        super(Main_title, self).__init__(value="Infinite", size=50, color=color.light_gray, x=355, y=75, is_collideable=False)

class Creator(games.Text):
    def __init__(self):
        super(Main_title, self).__init__(value="Made by: Kyla Ryan", size=30, color=color.light_gray, x=1435, y=555,
                                         is_collideable=False)


class Menu_animation(games.Animation):
    title_background_animation = ["images/title_screen1.jpg",
                                     "images/title_screen2.jpg",
                                     "images/title_screen3.jpg",
                                     "images/title_screen4.jpg"]
    # infinity_war=games.load_sound(("8_bit_themes/Infinity_War.ogg"))
    # infinity_war.play()
	
    def __init__(self):
        super(Menu_animation,self).__init__(images=Menu_animation.title_background_animation,
                                         x=games.screen.width/2,
                                         y=games.screen.height/2,
                                         n_repeats=0,
                                         repeat_interval=60,
                                         is_collideable=False)


    def update(self):


        global play
        if games.keyboard.is_pressed(games.K_RETURN):
            play = True
            games.music.stop()

            print("playing")
            games.music.load("8_bit_themes/Avengers.ogg")
            games.music.play()

            #
            self.destroy()





class Game(object):

    background = Background()
    thanos = Thanos()
    orb = Orb()
    score = SCVal()
    score_label = SCLab()

    #implement other songs later on
    #"8_bit_themes/Ant_Man.ogg", "8_bit_themes/GotG.ogg", "8_bit_themes/Iron_Man.ogg",
    #"8_bit_themes/Spider_Man.ogg", "8_bit_themes/Winter_Soldier.ogg"


    background_image = games.load_image("images/bkgrnd-3lf.jpg", transparent=False)

    games.screen.background = background_image
    # draw objects to screen
    games.screen.add(background)  # Avengers background image (will possibly change during the game)
    games.screen.add(orb)
    games.screen.add(thanos)
    games.screen.add(score)  # Score value to go with label (this is an int)
    games.screen.add(score_label)




###############
#Main~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def main():
    global play
    global thanos





    games.music.load("8_bit_themes/Infinity_War.ogg")

    games.music.play()
    menu=Menu_animation()
    games.screen.add(menu)

    print("before play game")


    if play==True:



        game=Game()
        games.screen.add(game)
    games.screen.mainloop()







    games.mouse.is_visible = True




    #Initiate main loop










###############
#Start up~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

main()

###############
